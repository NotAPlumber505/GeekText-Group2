package com.bookBrowser.GeekText_BookBrowser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeekTextBookBrowserApplicationTestsEntity {

	@Test
	void contextLoads() {
	}

}
